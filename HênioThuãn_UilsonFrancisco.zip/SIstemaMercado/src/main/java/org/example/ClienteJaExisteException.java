package org.example;

public class ClienteJaExisteException extends Exception {
	public ClienteJaExisteException(String msg){
		super(msg);
	}
	

}
