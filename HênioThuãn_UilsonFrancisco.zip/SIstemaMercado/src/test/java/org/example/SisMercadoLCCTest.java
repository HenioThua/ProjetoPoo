package org.example;

import org.example.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SisMercadoLCCTest {

    private SisMercadoLCC sisMercado;

    @Before
    public void setUp() {
        sisMercado = new SisMercadoLCC();
    }

    @Test(expected = UsuarioJaExisteException.class)
    public void testCadastrarUsuarioDuplicado() throws UsuarioJaExisteException {
        Usuario usuario1 = new Usuario("login", "senha", "Nome do Usuário");
        Usuario usuario2 = new Usuario("login", "senha", "Outro Usuário");
        sisMercado.CadastrarUsuario(usuario1);
        sisMercado.CadastrarUsuario(usuario2); // Deve lançar exceção
    }

    @Test
    public void testVerificarLogin() throws UsuarioJaExisteException {
        Usuario usuario = new Usuario("login", "nome", "senha");
        sisMercado.CadastrarUsuario(usuario);
        assertTrue(sisMercado.VerificarLogiin("login", "senha"));
        assertFalse(sisMercado.VerificarLogiin("login", "senhaErrada"));
    }

    @Test
    public void testPesquisarUsuarioComecandoCom() throws UsuarioJaExisteException {
        Usuario usuario1 = new Usuario("login1", "nome1", "senha1");
        Usuario usuario2 = new Usuario("login2", "nome2", "senha2");
        Usuario usuario3 = new Usuario("login3", "nome3", "senha3");
        sisMercado.CadastrarUsuario(usuario1);
        sisMercado.CadastrarUsuario(usuario2);
        sisMercado.CadastrarUsuario(usuario3);
        List<Usuario> usuarios = sisMercado.PesquisarUsuarioComecandoCom("nome");
        assertEquals(3, usuarios.size());
        assertTrue(usuarios.contains(usuario1));
        assertTrue(usuarios.contains(usuario2));
        assertTrue(usuarios.contains(usuario3));
    }

    @Test
    public void testCadastrarClientePF() throws ClienteJaExistePfException, IOException {
        ClientePF clientePF = new ClientePF("abcdefgh","12345678900");
        sisMercado.CadastrarClientePF(clientePF);
        List<ClientePF> clientesPF = sisMercado.ObterListaDeClientesPF();
        assertEquals(1, clientesPF.size());
        assertEquals(clientePF, clientesPF.get(0));
    }
}

