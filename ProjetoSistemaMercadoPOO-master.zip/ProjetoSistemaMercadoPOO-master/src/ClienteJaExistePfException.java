
public class ClienteJaExistePfException extends Exception {
		public ClienteJaExistePfException(String msg){
			super(msg);
		}
		

	}


